from .svm import SVM

__all__ = [
    'svm'
]
